
# Sahibinden Fırsat Araç Botu

Bu sistem:
- Sahibinden ilanlarını tarar
- Piyasa altı araçları tespit eder
- Telegram üzerinden bildirim yollar

## Kurulum

### 1. Python Kur
Python 3.11+

### 2. Gereksinimler
```bash
pip install -r requirements.txt
playwright install
```

### 3. Telegram Bot
Telegram'da @BotFather üzerinden bot oluştur.
Token'i `.env` içine yaz.

### 4. Çalıştır
```bash
python main.py
```

## Özellikler
- Yeni ilan takibi
- Fiyat karşılaştırması
- Fırsat puanı
- Telegram bildirimi
- Sahibinden kullanıcı filtreleme
